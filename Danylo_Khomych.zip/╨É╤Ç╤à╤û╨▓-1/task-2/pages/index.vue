<template>
  <main class="app">
    <DateNow/>
    <ImageGrid/>

  </main>
</template>

<script setup>

</script>

<style lang="scss" scoped>
  .app{
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 10px;
  }
</style>